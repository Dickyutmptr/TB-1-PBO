/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quizpbodicky.java;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author DUP
 */
public class QuizPboDickyJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<String> pola_pertama = new ArrayList<String>(5);
        pola_pertama.add("*");
        pola_pertama.add(" *\n**");
        pola_pertama.add("  *\n  *\n***");
        pola_pertama.add("   *\n   *\n   *\n****");

        ArrayList<String> pola_kedua = new ArrayList<String>(5);
        pola_kedua.add("*");
        pola_kedua.add("**\n**");
        pola_kedua.add("***\n* *\n***");
        pola_kedua.add("****\n*  *\n*  *\n****");

        ArrayList<String> pola_ketiga = new ArrayList<String>(5);
        pola_ketiga.add("*");
        pola_ketiga.add("**\n**");
        pola_ketiga.add("* *\n * \n* *\n");
        pola_ketiga.add("*  *\n ** \n ** \n*  *");
        pola_ketiga.add("*   *\n * * \n  *  \n * * \n*   *");

        ArrayList<String> pola_keempat = new ArrayList<String>(5);
        pola_keempat.add(" ");
        pola_keempat.add(" *\n* ");
        pola_keempat.add(" * \n* *\n * ");
        pola_keempat.add(" * *\n* * \n * *\n* * ");
        pola_keempat.add(" * * \n* * *\n * * \n* * *\n * * ");

        ArrayList<String> pola_kelima = new ArrayList<String>(4);
        pola_kelima.add("*");
        pola_kelima.add(" * \n* *\n * ");
        pola_kelima.add("  *  \n * * \n*   *\n * * \n  *  ");
        pola_kelima.add("   *   \n  * *  \n *   * \n*     *\n *   * \n  * *  \n   *   ");

        int inputPola, pola;
        Scanner input = new Scanner(System.in);

        while (true) {
            System.out.println("masukkan Tipe Pola <1-5> <-1 untuk berhenti>:");
            inputPola = input.nextInt();

            if (inputPola == 1) {
                System.out.print("masukkan sebuah angka: ");
                pola = input.nextInt();

                switch (pola) {
                    case 1:
                        System.out.println(pola_pertama.get(pola - 1));
                        break;
                    case 2:
                        System.out.println(pola_pertama.get(pola - 1));
                        break;
                    case 3:
                        System.out.println(pola_pertama.get(pola - 1));
                        break;
                    case 4:
                        System.out.println(pola_pertama.get(pola - 1));
                        break;
                    default:
                        break;
                }
            }
            if (inputPola == 2) {
                System.out.print("masukkan sebuah angka: ");
                pola = input.nextInt();

                switch (pola) {
                    case 1:
                        System.out.println(pola_kedua.get(pola - 1));
                        break;
                    case 2:
                        System.out.println(pola_kedua.get(pola - 1));
                        break;
                    case 3:
                        System.out.println(pola_kedua.get(pola - 1));
                        break;
                    case 4:
                        System.out.println(pola_kedua.get(pola - 1));
                        break;
                    default:
                        break;
                }
            }
            if (inputPola == 3) {
                System.out.print("masukkan sebuah angka: ");
                pola = input.nextInt();

                switch (pola) {
                    case 1:
                        System.out.println(pola_ketiga.get(pola - 1));
                        break;
                    case 2:
                        System.out.println(pola_ketiga.get(pola - 1));
                        break;
                    case 3:
                        System.out.println(pola_ketiga.get(pola - 1));
                        break;
                    case 4:
                        System.out.println(pola_ketiga.get(pola - 1));
                        break;
                    case 5:
                        System.out.println(pola_ketiga.get(pola - 1));
                        break;
                    default:
                        break;
                }
            }
            if (inputPola == 4) {
                System.out.print("masukkan sebuah angka: ");
                pola = input.nextInt();

                switch (pola) {
                    case 1:
                        System.out.println(pola_keempat.get(pola - 1));
                        break;
                    case 2:
                        System.out.println(pola_keempat.get(pola - 1));
                        break;
                    case 3:
                        System.out.println(pola_keempat.get(pola - 1));
                        break;
                    case 4:
                        System.out.println(pola_keempat.get(pola - 1));
                        break;
                    case 5:
                        System.out.println(pola_keempat.get(pola - 1));
                        break;
                    default:
                        break;
                }
            }
            if (inputPola == 5) {
                System.out.print("masukkan sebuah angka: ");
                pola = input.nextInt();

                switch (pola) {
                    case 1:
                        System.out.println(pola_kelima.get(0));
                        break;
                    case 3:
                        System.out.println(pola_kelima.get(1));
                        break;
                    case 5:
                        System.out.println(pola_kelima.get(2));
                        break;
                    case 7:
                        System.out.println(pola_kelima.get(3));
                        break;
                    default:
                        break;
                }
            }
            if (inputPola == -1) {
                break;
            }
        }
        input.close();
    }
}